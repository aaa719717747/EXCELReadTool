﻿/// <summary>
/// 菜单实体类
/// </summary>
[System.Serializable]
public class Menu
{
    public string m_Id;
    public string m_level;
    public string m_parentId;
    public string m_name;
}
